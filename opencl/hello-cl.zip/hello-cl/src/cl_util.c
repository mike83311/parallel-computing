/*
 *  cl_util.c
 *  hello-cl
 *
 *  Created by Chung-Yu Liao in 2016.
 *  Copyright © 2016 NTNU Parallel Computing Lab. All rights reserved.
 */

#include "cl_util.h"

/* A utility function to simplify error checking. */
static void check_status(char* msg, cl_int err, bool *is_failed)
{
  if (err != CL_SUCCESS)
  {
    fprintf(stderr, "%s failed. Error: %d\n", msg, err);
    if (is_failed != NULL)
      *is_failed = true;
  }
}

/* Begin of the implementation. */
bool initDeviceCL(
    cl_context *context, cl_command_queue *queue,
    cl_device_type type, const int count)
{
  bool is_failed = false;
  cl_int err;
  cl_uint num;

  err = clGetPlatformIDs(0, 0, &num);
  check_status("clGetPlatforms", err, &is_failed);

  cl_platform_id *platforms = (cl_platform_id *)malloc(
      num * sizeof(cl_platform_id));
	err = clGetPlatformIDs(num, platforms, &num);
  check_status("clGetPlatformIDs", err, &is_failed);

	cl_context_properties prop[] = {
      CL_CONTEXT_PLATFORM, (cl_context_properties)platforms[0], 0};
	*context = clCreateContextFromType(prop, CL_DEVICE_TYPE_GPU, NULL, NULL, &err);
	check_status("clCreateContextFromType", err, &is_failed);

	size_t cb;
	clGetContextInfo(*context, CL_CONTEXT_DEVICES, 0, NULL, &cb);
	cl_device_id *devices = (cl_device_id *)malloc(cb * sizeof(cl_device_id));
	clGetContextInfo(*context, CL_CONTEXT_DEVICES, cb, devices, 0);

  clGetDeviceInfo(devices[count], CL_DEVICE_NAME, 0, NULL, &cb);
  char *devname = (char *)malloc(cb * sizeof(char));
  clGetDeviceInfo(devices[count], CL_DEVICE_NAME, cb, devname, 0);
  fprintf(stdout, "Device: %s\n", devname);

  clGetDeviceInfo(devices[count], CL_DEVICE_VERSION, 0, NULL, &cb);
  char *ver = (char *)malloc(cb * sizeof(char));
	clGetDeviceInfo(devices[count], CL_DEVICE_VERSION, cb, ver, 0);
	fprintf(stdout, "OpenCL Version: %s\n", ver);

  *queue = clCreateCommandQueue(*context, devices[0], 0, &err);
  check_status("clGetPlatforms", err, &is_failed);
	if(is_failed)
    releaseDeviceCL(context, queue);

  free(platforms);
  free(devices);
  free(devname);
  free(ver);

  return !is_failed;
}

bool releaseDeviceCL(cl_context *context, cl_command_queue *queue)
{
  cl_int err;

  err = clReleaseCommandQueue(*queue);
  if (clReleaseContext(*context) != CL_SUCCESS)
    err = CL_FALSE;

  return (err == CL_SUCCESS);
}
