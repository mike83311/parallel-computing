/* adder.cl.c */
extern unsigned char adder_cl[];
extern unsigned int adder_cl_len;
