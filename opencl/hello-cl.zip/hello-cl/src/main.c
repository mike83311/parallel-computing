#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <stdbool.h>

/* OpenCL utility. */
#include "cl_util.h"
/* A header file of the kernel source that will be generated on compiling. */
#include "adder.cl.h"

/* The size of test data. */
#define DATA_SIZE 1048576


int main(const int argc, const char *argv[])
{
  cl_int err;
  cl_context context = NULL;
  cl_command_queue queue = NULL;

  /* Initialize the OpenCL device. */
	if (!initDeviceCL(&context, &queue, CL_DEVICE_TYPE_GPU, 0))
  {
    fprintf(stderr, "Cannot initialize the OpenCL device.\n");
    return EXIT_FAILURE;
  }

  /* Generate test data. */
	float *a, *b, *res;
  a = malloc(DATA_SIZE * sizeof(float));
  b = malloc(DATA_SIZE * sizeof(float));
  res = malloc(DATA_SIZE * sizeof(float));
  srand(time(NULL));
	for(int i = 0; i < DATA_SIZE; i++) {
		a[i] = (float)rand() / (float)RAND_MAX;;
		b[i] = (float)rand() / (float)RAND_MAX;;
	}

  /* Create the OpenCL buffer and copy the test data to the buffer. */
	cl_mem cl_a = clCreateBuffer(
      context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR,
      sizeof(cl_float) * DATA_SIZE, &a[0], NULL);
	cl_mem cl_b = clCreateBuffer(
      context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR,
      sizeof(cl_float) * DATA_SIZE, &b[0], NULL);
	cl_mem cl_res = clCreateBuffer(
      context, CL_MEM_WRITE_ONLY,
      sizeof(cl_float) * DATA_SIZE, NULL, NULL);
	if(cl_a == 0 || cl_b == 0 || cl_res == 0)
  {
		fprintf(stderr, "Cannot create OpenCL buffer\n");
		clReleaseMemObject(cl_a);
		clReleaseMemObject(cl_b);
		clReleaseMemObject(cl_res);
    free(a);
    free(b);
    free(res);
		releaseDeviceCL(&context, &queue);
		return EXIT_FAILURE;
	}

  /* Create the OpenCL program. */
  const char *prog_source = (const char *)adder_cl;
  cl_program program = clCreateProgramWithSource(
      context, 1, &prog_source, (const size_t *)&adder_cl_len, &err);
  if (err != CL_SUCCESS)
  {
    fprintf(stderr, "Cannot create the OpenCL program.\n");
    clReleaseMemObject(cl_a);
		clReleaseMemObject(cl_b);
		clReleaseMemObject(cl_res);
    free(a);
    free(b);
    free(res);
    releaseDeviceCL(&context, &queue);
		return EXIT_FAILURE;
  }

  /* Load the OpenCL program. */
  err = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
  if (err != CL_SUCCESS)
  {
    fprintf(stderr, "Cannot load the OpenCL program.\n");
    clReleaseMemObject(cl_a);
		clReleaseMemObject(cl_b);
		clReleaseMemObject(cl_res);
    free(a);
    free(b);
    free(res);
    releaseDeviceCL(&context, &queue);
		return EXIT_FAILURE;
  }

  /* Load the OpenCL kernel of the program. */
	cl_kernel adder = clCreateKernel(program, "adder", &err);
	if(err != CL_SUCCESS)
  {
		fprintf(stderr, "Cannot load the OpenCL kernel.\n");
    clReleaseProgram(program);
		clReleaseMemObject(cl_a);
		clReleaseMemObject(cl_b);
		clReleaseMemObject(cl_res);
    free(a);
    free(b);
    free(res);
		releaseDeviceCL(&context, &queue);
		return EXIT_FAILURE;
	}

  /* Set the arguments of the OpenCL kernel. */
	clSetKernelArg(adder, 0, sizeof(cl_mem), &cl_a);
	clSetKernelArg(adder, 1, sizeof(cl_mem), &cl_b);
	clSetKernelArg(adder, 2, sizeof(cl_mem), &cl_res);

  /* Enqueue the OpenCL kernel. */
	size_t work_size = DATA_SIZE;
	err = clEnqueueNDRangeKernel(queue, adder, 1, 0, &work_size, 0, 0, 0, 0);

  /* Read back the data from the OpenCL buffer. */
	if(err == CL_SUCCESS)
		err = clEnqueueReadBuffer(
        queue, cl_res, CL_TRUE, 0, sizeof(float) * DATA_SIZE, &res[0], 0, 0, 0);

  /* Check if the result of the test data is equal to cpu's calculation. */
	if(err == CL_SUCCESS) {
		bool correct = true;
		for(int i = 0; i < DATA_SIZE; i ++)
    {
			if(a[i] + b[i] != res[i])
      {
        fprintf(stdout, "a=%f, b=%f, res=%f\n", a[i], b[i], res[i]);
				correct = false;
				break;
			}
		}

		if(correct)
      fprintf(stdout, "Data is correct.\n");
		else
			fprintf(stdout, "Data is incorrect.\n");
	}
	else
    fprintf(stderr, "Cannot run kernel or read back data.\n");

	clReleaseKernel(adder);
	clReleaseProgram(program);
	clReleaseMemObject(cl_a);
	clReleaseMemObject(cl_b);
	clReleaseMemObject(cl_res);
  free(a);
  free(b);
  free(res);
  releaseDeviceCL(&context, &queue);

	return EXIT_SUCCESS;
}
