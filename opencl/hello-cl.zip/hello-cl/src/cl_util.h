/*
 *  cl_util.h
 *  hello-cl
 *
 *  Created by Chung-Yu Liao in 2016.
 *  Copyright © 2016 NTNU Parallel Computing Lab. All rights reserved.
 */

#ifndef __CL_UTIL_H__
#define __CL_UTIL_H__

#include <stdio.h>

#include <stdbool.h>

#ifdef __APPLE__
#include <OpenCL/opencl.h>
#else
#include <CL/cl.h>
#endif

/*
Initialize the OpenCL Device.

_Parameters
    context: A context of the OpenCL device.
    queue:   A command queue of the OpenCL device.
    type:    A bit-field that identifies the type of device. It can be:
            [CL_DEVICE_TYPE_CPU, CL_DEVICE_TYPE_GPU, CL_DEVICE_TYPE_ACCELERATOR,
             CL_DEVICE_TYPE_DEFAULT, CL_DEVICE_TYPE_ALL].
    count: Index from the list of the devices.

_Return
    Success: true
    Failure: false
*/
bool initDeviceCL(
    cl_context *context, cl_command_queue *queue,
    const cl_device_type type, const int count);

/*
Release the OpenCL Device.

_Parameters
    context: A context of the OpenCL device.
    queue:   A command queue of the OpenCL device.

_Return
    Success: true
    Failure: false
*/
bool releaseDeviceCL(
    cl_context *context, cl_command_queue *queue);

#endif /* __CL_UTIL_H__ */
