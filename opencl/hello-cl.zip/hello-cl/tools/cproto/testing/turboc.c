/*LINT_EXTERN*/
#include <sys/stat.h>
#include <sys/timeb.h>
#include <sys/types.h>

#include <alloc.h>
#include <assert.h>
/* C++ only #include <bcd.h> */
#include <bios.h>
/* C++ only #include <complex.h> */
#include <conio.h>
/* C++ only #include <constrea.h> */
#include <ctype.h>
#include <dir.h>
#include <direct.h>
#include <dirent.h>
#include <dos.h>
#include <errno.h>
#include <fcntl.h>
#include <float.h>
/* C++ only #include <fstream.h> */
/* C++ only #include <generic.h> */
#include <graphics.h>
#include <io.h>
/* C++ only #include <iomanip.h> */
/* C++ only #include <iostream.h> */
#include <limits.h>
#include <locale.h>
#include <locking.h>
#include <malloc.h>
#include <math.h>
#include <mem.h>
#include <memory.h>
/* C++ only #include <new.h> */
#include <process.h>
#include <search.h>
#include <setjmp.h>
#include <share.h>
#include <signal.h>
#include <stat.h>
/* ? #include <stdarg.h> */
#include <stddef.h>
#include <stdio.h>
/* C++ only #include <stdiostr.h> */
#include <stdlib.h>
#include <string.h>
/* C++ only #include <strstrea.h> */
#include <time.h>
#include <timeb.h>
#include <types.h>
#include <utime.h>
#include <values.h>
/* ? #include <varargs.h> */
