# xxd - Hexdump utility #

This is a clone of Juergen Weigert's hexdump utility, `xxd`.

To use, just run `make`, and an executable will be compiled.

## License ##

(c) 1990-1998 by Juergen Weigert (jnweiger@informatik.uni-erlangen.de).

    Distribute freely and credit me,
    make money and share with me,
    lose money and don't ask me.
